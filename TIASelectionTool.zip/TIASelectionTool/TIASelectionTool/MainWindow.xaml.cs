﻿using System.Composition;
using System.Windows;
using TIASelectionTool.ViewModel;

namespace TIASelectionTool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        [ImportingConstructor]
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new TIASelectionToolViewModel();
        }
    }
}
