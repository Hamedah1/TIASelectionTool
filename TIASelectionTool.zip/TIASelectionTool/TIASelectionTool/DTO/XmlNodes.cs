﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIASelectionTool.DTO
{
   public class XmlNodes
    {
        public string NodeName { get; set; }
        public int NodeCount { get; set; }
    }
}
