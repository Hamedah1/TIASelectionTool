﻿namespace TIASelectionTool.DTO
{
    public class XmlChildsNode
    {
        //public string NodeName { get; set; }
        //public string NodeNameChild { get; set; }
        public string NodeNamechildValue { get; set; }
        public int NodeChildcount { get; set; }
    }
}
