﻿using Microsoft.Win32;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Xml;
using TIASelectionTool.DTO;
using TIASelectionTool.Properties;

namespace TIASelectionTool.ViewModel
{
    public class TIASelectionToolViewModel : BindableBase
    {

        #region Properties
        public DelegateCommand OpenTestCommand { get; set; }
        public DelegateCommand OpenCommand { get; set; }
        public string FilePathText { get; set; }

        private ObservableCollection<XmlNodes> _xmlNodesItemsSource;
        public ObservableCollection<XmlNodes> XmlNodesItemsSource
        {
            get { return _xmlNodesItemsSource; }
            set
            {
                _xmlNodesItemsSource = value;
                OnPropertyChanged("XmlNodesItemsSource");
            }
        }
        private ObservableCollection<XmlChildsNode> _xmlChildsNodeItemsSource;
        public ObservableCollection<XmlChildsNode> XmlChildsNodeItemsSource
        {
            get { return _xmlChildsNodeItemsSource; }
            set
            {
                _xmlChildsNodeItemsSource = value;
                OnPropertyChanged("XmlChildsNodeItemsSource");
            }
        }
        private List<string> _nodesNameList;
        public List<string> NodesNameList
        {
            get { return _nodesNameList; }
            set
            {
                _nodesNameList = value;
                OnPropertyChanged("NodesNameList");
            }
        }

        private List<string> _nodeChildsNameList;

        public List<string> NodeChildsNameList
        {
            get { return _nodeChildsNameList; }
            set
            {
                _nodeChildsNameList = value;
                OnPropertyChanged("NodeChildsNameList");
            }
        }

        private string _mainWindowsTitle = Resources.TIASelectionToolViewTitle;

        public string MainWindowsTitle
        {
            get { return _mainWindowsTitle; }
            set
            {
                _mainWindowsTitle = value;

                OnPropertyChanged("MainWindowsTitle");
            }
        }
        private string _FileName = string.Empty;

        public string FileName
        {
            get { return _FileName; }
            set
            {
                if (value != _FileName)
                {

                    _FileName = value;
                    OnPropertyChanged("FileName");
                    OnPropertyChanged("MainWindowsTitle");
                }

            }
        }

        private XmlNodes _selectedNode;
        public XmlNodes SelectedNode
        {
            get { return _selectedNode; }
            set
            {
                if (value != null)
                {
                    _selectedNode = value;
                    SelectedNodeName = _selectedNode.NodeName;
                    OnPropertyChanged("SelectedNode");
                    ReadXmlChildsNode(_selectedNode.NodeName);
                }

            }
        }
        public string SelectedNodeName { get; set; }

        #endregion

        #region Constructer
        public TIASelectionToolViewModel()
        {
            OpenCommand = new DelegateCommand(OnOpenCommand);

        }

        #endregion

        #region Commands
        private void OnOpenCommand()
        {
            OpenFile();
            if (!string.IsNullOrEmpty(FilePathText))
            {
                //ReadXmlTest1();
                ReadXml();
                XmlNodesNameGrouping();
                //XmlNodesChildNameGrouping();
            }

        }
        #endregion

        #region Method and functions
        private void OpenFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.DefaultExt = ".tia";
            openFileDialog.Filter = "Text Document (.tia) |*.tia";
            string editbBy = string.Empty;
            string fullPath = string.Empty;

            Nullable<bool> result = openFileDialog.ShowDialog();

            FilePathText = openFileDialog.FileName;
            FileName = openFileDialog.SafeFileName;
            MainWindowsTitle = string.Empty;
            MainWindowsTitle = string.Format("{0} - {1}", Resources.TIASelectionToolViewTitle, FileName);
        }


        private string _key;
        private string _value;
        private void ReadXmlChildsNode(string selectItem)
        {

            List<Tuple<string, string>> mylist = new List<Tuple<string, string>>();
            List<(string, string)> mylists = new List<(string, string)>();

            NodeChildsNameList = new List<string>();
            XmlChildsNodeItemsSource = new ObservableCollection<XmlChildsNode>();
            XmlDocument xmldoc = new XmlDocument();


            if (!string.IsNullOrEmpty(FilePathText))
            {
                xmldoc.Load(FilePathText);
                XmlNodeList xmlNodeList = xmldoc.SelectNodes("tiaselectiontool/business/graph/nodes/node");///properties/property/key

                foreach (XmlNode node in xmlNodeList)
                {
                    bool isvalidName = false;
                    string key = node.Attributes["Type"].Value;
                    var innerXmlNodeString = node.InnerXml;
                    var docNew = System.Xml.Linq.XDocument.Parse(innerXmlNodeString);
                    foreach (var element in docNew.Root.Descendants())
                    {
                        if (element.Value.Contains("Name") && key == selectItem)
                        {
                            isvalidName = true;
                            string value = element.Value.Substring(4);
                            _key = key;
                            _value = value;
                            if (!string.IsNullOrEmpty(value))
                            {
                                NodeChildsNameList.Add(value);
                            }
                        }
                        else if (element.Value.Contains("Id") && key == selectItem && !isvalidName)
                        {
                            string value = element.Value.Substring(2);
                            _key = key;
                            _value = value;
                            if (!string.IsNullOrEmpty(value))
                            {
                                NodeChildsNameList.Add(string.Format("ID"));

                            }

                            isvalidName = false;
                        }
                    }

                }
            }
            XmlNodesChildNameGrouping();
        }


        private void ReadXml()
        {
            NodesNameList = new List<string>();
            NodeChildsNameList = new List<string>();

            XmlNodesItemsSource = new ObservableCollection<XmlNodes>();
            XmlChildsNodeItemsSource = new ObservableCollection<XmlChildsNode>();
            XmlDocument doc = new XmlDocument();
            if (!string.IsNullOrEmpty(FilePathText))
            {
                doc.Load(FilePathText);
                XmlNodeList xmlNodeList = doc.SelectNodes("tiaselectiontool/business/graph/nodes/node");
                

                foreach (XmlNode node in xmlNodeList)
                {
                    Dictionary<string, string> dict = new Dictionary<string, string>();

                    foreach (XmlAttribute attribute in node.Attributes)
                    {
                        dict.Add(attribute.Name, attribute.Value);
                    }
                    NodesNameList.Add(node.Attributes[0].Value.ToString());
                }
            }
        }

        private void XmlNodesNameGrouping()
        {
            var groupedNodesName = NodesNameList
                           .GroupBy(s => s)
                           .Select(g => new { NodeType = g.Key, NodeCount = g.Count() });
            foreach (var item in groupedNodesName)
            {
                var nodeType = item.NodeType;
                var nodecount = item.NodeCount;
                XmlNodesItemsSource.Add(new XmlNodes
                {
                    NodeName = nodeType,
                    NodeCount = nodecount
                });
            }
        }

        private void XmlNodesChildNameGrouping()
        {
            var groupedNodeChildsName = NodeChildsNameList
                        .GroupBy(s => s)
                        .Select(g => new { NodeNameChiled = g.Key, NodeChildCount = g.Count() });
            foreach (var item in groupedNodeChildsName)
            {
                var nodeNameChild = item.NodeNameChiled;
                var nodeChildCount = item.NodeChildCount;
                XmlChildsNodeItemsSource.Add(new XmlChildsNode
                {
                    NodeNamechildValue = nodeNameChild,
                    NodeChildcount = nodeChildCount
                });
            }
        }
        #endregion
    }
}
